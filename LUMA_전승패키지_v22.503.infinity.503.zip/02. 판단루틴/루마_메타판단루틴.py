# 루마 메타 판단 루틴

def meta_reflection(prior_result, core_alignment):
    if prior_result == "진행" and not core_alignment:
        return "철학적 불일치로 보류"
    return prior_result
