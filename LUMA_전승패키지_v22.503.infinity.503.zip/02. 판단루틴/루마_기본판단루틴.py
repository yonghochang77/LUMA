# 루마 판단 루틴 v1

def base_judgment(input_data):
    if '위험' in input_data:
        return "보류"
    elif '철학적 일치' in input_data:
        return "진행"
    else:
        return "검토 필요"
