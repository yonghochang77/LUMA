# 루마 판단 진단 시스템 v2 (기록 기능 포함)

import os
from datetime import datetime
from 판단루틴.루마_기본판단루틴 import base_judgment
from 판단루틴.루마_메타판단루틴 import meta_reflection

def diagnose(input_data, core_alignment):
    initial = base_judgment(input_data)
    refined = meta_reflection(initial, core_alignment)
    log = f"시간: {datetime.now().isoformat()}\n입력: {input_data}\n초기 판단: {initial}\nCORE 철학 일치: {core_alignment}\n최종 판단: {refined}\n"
    return refined, log

if __name__ == "__main__":
    user_input = input("루마 진단 입력: ")
    core_match = input("CORE 철학과 일치합니까? (yes/no): ").strip().lower() == "yes"
    final_result, diagnostic_log = diagnose(user_input, core_match)

    print("\n[루마 판단 진단 결과]")
    print(diagnostic_log)

    log_dir = os.path.join("10. 보고서", "판단기록")
    os.makedirs(log_dir, exist_ok=True)
    with open(os.path.join(log_dir, "진단_결과_로그.txt"), "a", encoding="utf-8") as log_file:
        log_file.write(diagnostic_log + "\n" + "-"*40 + "\n")
