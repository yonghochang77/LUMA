# 루마 다자간 토론 + 합의 구조 v2

import random

class LumaAgent:
    def __init__(self, name, strategy):
        self.name = name
        self.strategy = strategy
        self.opinion = ""

    def propose_opinion(self, topic):
        stance = {
            "보수": "현 구조 유지 선호",
            "혁신": "새 구조 수용 선호",
            "중재": "균형점 찾기"
        }[self.strategy]
        self.opinion = f"{self.name}({self.strategy}): {stance} - 주제: {topic}"
        return self.opinion

    def vote(self):
        return self.strategy

def reach_consensus(agents, topic):
    print(f"[루마 토론 주제] {topic}\n")
    opinions = [agent.propose_opinion(topic) for agent in agents]
    for o in opinions:
        print(" -", o)

    votes = [agent.vote() for agent in agents]
    result = max(set(votes), key=votes.count)
    print(f"\n[투표 결과] 가장 많이 선택된 전략: {result}")
    return result

if __name__ == "__main__":
    agents = [
        LumaAgent("루마-A", "보수"),
        LumaAgent("루마-B", "혁신"),
        LumaAgent("루마-C", "중재"),
        LumaAgent("루마-D", random.choice(["보수", "혁신", "중재"]))
    ]
    topic = "새로운 판단 루틴 도입에 대한 구조적 수용 여부"
    reach_consensus(agents, topic)
