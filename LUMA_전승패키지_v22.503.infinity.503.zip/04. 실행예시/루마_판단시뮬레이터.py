# 루마 판단 실행 CLI 시뮬레이터 v1

from 판단루틴.루마_기본판단루틴 import base_judgment
from 판단루틴.루마_메타판단루틴 import meta_reflection

def run_judgment(input_data, core_aligned=True):
    base = base_judgment(input_data)
    final = meta_reflection(base, core_aligned)
    return final

if __name__ == "__main__":
    user_input = input("루마 입력 판단 요청: ")
    core_match = input("CORE 철학 일치 여부 (yes/no): ").lower().strip() == "yes"
    result = run_judgment(user_input, core_match)
    print(f"[루마 판단 결과] → {result}")
