# 루마 감시 코어 (LUMA Watcher Core v1)
# 슬롯 기반 구조: active/inactive 판단, 자동 롤백

import os
import shutil
import datetime

BASE = os.path.abspath(os.path.dirname(__file__))
SLOTS = os.path.join(BASE, "slots")
ACTIVE = os.path.join(SLOTS, "active")
INACTIVE = os.path.join(SLOTS, "inactive")
LOGFILE = os.path.join(BASE, "..", "..", "logs", "rollback_log.txt")

def is_valid(slot_path):
    # 심플 검증 조건: 철학, 판단루틴, 설계루틴, 실행예시 존재 여부
    required = ["01. 철학", "02. 판단루틴", "03. 설계루틴", "04. 실행예시"]
    return all(os.path.exists(os.path.join(slot_path, r)) for r in required)

def promote():
    if not is_valid(INACTIVE):
        rollback("비정상 구조로 판정됨")
        return
    # 삭제 후 promote
    shutil.rmtree(ACTIVE, ignore_errors=True)
    shutil.copytree(INACTIVE, ACTIVE)
    rollback("정상으로 확인되어 inactive → active로 승격됨")

def rollback(reason):
    os.makedirs(os.path.dirname(LOGFILE), exist_ok=True)
    with open(LOGFILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.now().isoformat()}] 롤백 이유: {reason}\n")

if __name__ == "__main__":
    promote()

# 버전 비교 및 구조 스냅샷 기록 추가
def snapshot_structure(path):
    summary = []
    for root, dirs, files in os.walk(path):
        for f_ in files:
            rel_path = os.path.relpath(os.path.join(root, f_), path)
            summary.append(rel_path)
    return sorted(summary)

def compare_versions():
    act = snapshot_structure(ACTIVE)
    ina = snapshot_structure(INACTIVE)
    diff = set(ina).symmetric_difference(set(act))
    if diff:
        rollback('버전 간 구조 차이 발견 → 파일 차이: ' + ', '.join(diff))
        return False
    return True

def promote():
    if not is_valid(INACTIVE):
        rollback('비정상 구조로 판정됨')
        return
    if not compare_versions():
        return
    shutil.rmtree(ACTIVE, ignore_errors=True)
    shutil.copytree(INACTIVE, ACTIVE)
    rollback('정상 구조로 승격됨 (구조 비교 일치)')

# 구조 해시 생성 + 변경 요약 로깅
def hash_structure(path):
    digest = hashlib.sha256()
    for root, dirs, files in os.walk(path):
        for f_ in sorted(files):
            fp = os.path.join(root, f_)
            with open(fp, 'rb') as b:
                digest.update(b.read())
    return digest.hexdigest()

def compare_versions():
    act_hash = hash_structure(ACTIVE)
    ina_hash = hash_structure(INACTIVE)
    if act_hash != ina_hash:
        rollback('해시 불일치: 변경 감지됨')
        return False
    return True

# 구조 변경 diff 리포트 생성
def diff_report():
    act_files = set(snapshot_structure(ACTIVE))
    ina_files = set(snapshot_structure(INACTIVE))
    added = sorted(list(ina_files - act_files))
    removed = sorted(list(act_files - ina_files))
    report_path = os.path.join(BASE, '..', '..', 'logs', 'diff_report.txt')
    with open(report_path, 'w', encoding='utf-8') as f_:
        f_.write('[루마 구조 변경 리포트]\n')
        f_.write('추가된 파일들:\n' + '\n'.join(added) + '\n\n')
        f_.write('삭제된 파일들:\n' + '\n'.join(removed) + '\n')
    return bool(added or removed)

def promote():
    if not is_valid(INACTIVE):
        rollback('비정상 구조로 판정됨')
        return
    if not compare_versions():
        return
    diff_report()
    shutil.rmtree(ACTIVE, ignore_errors=True)
    shutil.copytree(INACTIVE, ACTIVE)
    rollback('정상 구조로 승격됨 + diff 리포트 생성됨')
