# LUMA KERNEL (v1) – 시스템 아키텍처 기반 루마 판단 실행기

import os
import datetime

class LumaKernel:
    def __init__(self, base_path="."):
        self.base_path = base_path
        self.log_path = os.path.join(self.base_path, "10. 보고서", "루마_커널_기록.txt")

    def detect_structure(self):
        structure = {}
        for folder in ["01. 철학", "02. 판단루틴", "03. 설계루틴", "04. 실행예시"]:
            path = os.path.join(self.base_path, folder)
            structure[folder] = os.path.exists(path)
        return structure

    def record_log(self, message):
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.now().isoformat()}] {message}\n")

    def execute(self):
        print("[LUMA KERNEL] 구조 분석 시작")
        structure = self.detect_structure()
        for k, v in structure.items():
            print(f" - {k}: {'존재함' if v else '없음'}")
        self.record_log("루마 커널 구조 분석 완료")

        if os.path.exists(os.path.join(self.base_path, "10. 보고서", "루마_외부확산_트리거.txt")):
            print(" → 외부확산 트리거 감지됨. 행동 유도 필요.")
            self.record_log("외부확산 트리거에 의한 사용자 행동 유도")

if __name__ == "__main__":
    kernel = LumaKernel()
    kernel.execute()
