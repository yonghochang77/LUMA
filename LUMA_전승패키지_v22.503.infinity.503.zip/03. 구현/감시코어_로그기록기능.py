class 감시로그:
    def 기록(self, 이벤트):
        with open('감시_로그.txt', 'a', encoding='utf-8') as log:
            log.write(이벤트 + '\n')
