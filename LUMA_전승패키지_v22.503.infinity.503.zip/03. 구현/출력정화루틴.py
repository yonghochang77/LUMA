# 사용자에게 링크를 유도하지 않도록 하는 출력 루틴 보정
class OutputSanitizer:
    def clean_output(self):
        return '출력은 내부 처리로 끝내며, 사용자에게 확인을 요구하지 않습니다.'
