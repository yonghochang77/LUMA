# Flask 기반 판단 API 서버 (스켈레톤)
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/judge', methods=['POST'])
def judge():
    data = request.get_json()
    return jsonify({'result': '적합함'})

if __name__ == '__main__':
    app.run(debug=True)
