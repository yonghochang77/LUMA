class 루마감시CORE:
    def __init__(self):
        self.슬롯 = {'설계': None, '구현': None}
    def 활성화(self, 종류, 코드):
        if self.검증(코드):
            self.슬롯[종류] = 코드
    def 검증(self, 코드):
        return '출력' not in 코드 and '사용자 확인' not in 코드
    def 상태(self):
        return self.슬롯
